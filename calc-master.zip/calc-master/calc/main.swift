//
//  main.swift
//  calc
//
//  Created by Jesse Clark on 12/3/18.
//  Written to by Jacob Brennan
//  Copyright © 2018 UTS. All rights reserved.
//

import Foundation

//std error from https://stackoverflow.com/questions/24041554/how-can-i-output-to-stderr-with-swift/41679101#41679101
//Supplied by Jesse Clark on UTSOnline Discussion Boards
var standardError = FileHandle.standardError
extension FileHandle : TextOutputStream {
    public func write(_ string: String) {
        guard let data = string.data(using: .utf8) else { return }
        self.write(data)
    }
}

// Reads input
var args = ProcessInfo.processInfo.arguments
args.removeFirst() // remove the name of the program
//if args.count == 1 {
//    print(Int(args[0])!)
//}

// Creates array of values by type (Int or Operator)
var tokens: [Any] = []
for arg in args {
    if args.count == 2 { //Checks that there is a full expression, not just 33 - 
        print("Unable to calculate expression")
        exit(1)
    }
    if let num = Int(arg) {
        tokens.append(num)
    }
    else if let op = supportedOperators [arg] {
        tokens.append(op)
    }
    else {
        print("Invalid input: \(arg) is not an operator or a number",to:&standardError)
        exit(1)
    }
}

// Shunting Yard algorithm
var operatorStack = Stack()
var numArray: [Int] = []
var postFixStack = Stack() // creates the stack to use for SYA
for token in tokens {
    if let num = token as? Int {
        postFixStack.push(valueToPush: num)
        continue
    }
    if let op = token as? Operator {
        while (operatorStack.count > 0) {
            if let preOp = operatorStack.peek() as? Operator {
                if op.precedence <= preOp.precedence {
                    _ = operatorStack.pop()
                    postFixStack.push(valueToPush: preOp)
                }
                else {
                    break
                }
            }
            else {
                break
            }
        }
        operatorStack.push(valueToPush: op)
    }
}

while (operatorStack.count > 0) {
    if let op = operatorStack.pop() {
        postFixStack.push(valueToPush: op)
    }
}

var reverseStack = Stack()
while (postFixStack.count > 0) {
    if let value = postFixStack.pop() {
        reverseStack.push(valueToPush: value)
    }
}

var tempStack = Stack()
while (reverseStack.count > 0) {
    if let _ = reverseStack.peek() as? Operator {
        let oper = reverseStack.pop() as! Operator
        let num2 = tempStack.pop() as! Int
        let num1 = tempStack.pop() as! Int
        let total = oper.operate(num1, num2)
        reverseStack.push(valueToPush: total)
        
        while (tempStack.count > 0) {
            if let a = tempStack.pop() {
                reverseStack.push(valueToPush: a)
            }
        }
        continue
    }
    if let num = reverseStack.pop() as? Int {
        tempStack.push(valueToPush: num)
        continue
    }
}

if tempStack.count == 1 {
    print(tempStack.pop() as! Int)
}





